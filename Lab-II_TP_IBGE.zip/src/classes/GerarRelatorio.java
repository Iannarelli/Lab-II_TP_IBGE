package classes;

public class GerarRelatorio {
	
	public void populacaoToral(){
		
	}
	
	public void taxaSexo(){
		
	}
	
	public void EstadoCivil(){
		
	
	}
	
	public void RacaPopu(){
		
	}
	
	public void Moradia(){
		
	}
	
	public void faixaEtaria(){
		
	}
	
	public void mediaIdade(){
		
	}
	
	public void MediaIdesvioP() {
		
	}
}
