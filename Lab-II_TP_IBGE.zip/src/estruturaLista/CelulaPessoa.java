package estruturaLista;

import classes.Pessoa;

public class CelulaPessoa {

	Pessoa item; 
	CelulaPessoa proximo; 
	 
	CelulaPessoa(){ 
		item = new Pessoa(); 
		proximo = null; 
	}
}
